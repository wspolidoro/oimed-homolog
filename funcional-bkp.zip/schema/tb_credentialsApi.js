const { DataTypes } = require('sequelize');
module.exports = (sequelize) => {
  const Credential = sequelize.define('Credential', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    nome: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    api_key: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    secret_key: {
      type: DataTypes.STRING(500),
      allowNull: false
    }
  }, {
    tableName: 'credentials',
    timestamps: false
  });
  return Credential;
};