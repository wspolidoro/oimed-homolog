const Sequelize = require('sequelize');
const { sequelize, sandbox } = require('../db');

const Franqueado = sequelize.define('oi_franqueado', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },

    nome: {
        type: Sequelize.STRING(150),
        allowNull: false,
        unique: false,
        validate: {
            notEmpty: {
                msg: "Esse campo não pode está vazio.."
            },
        }
    },

    cpf: {
        type: Sequelize.STRING(150),
        allowNull: false,
        unique: false,
        validate: {
            notEmpty: {
                msg: "Esse campo não pode está vazio.."
            },
        }
    },

    telefone: {
        type: Sequelize.STRING(150),
        allowNull: false,
        unique: false,
        validate: {
            notEmpty: {
                msg: "Esse campo não pode está vazio.."
            },
        }
    },

    email: {
        type: Sequelize.STRING(150),
        allowNull: false,
        unique: false,
        validate: {
            notEmpty: {
                msg: "Esse campo não pode está vazio.."
            },
        }
    },

    password: {
        type: Sequelize.STRING(150),
        allowNull: false,
        unique: false,
        validate: {
            notEmpty: {
                msg: "Esse campo não pode está vazio.."
            },
        }
    },

    total_clientes: {
        type: Sequelize.STRING(150),
        allowNull: false,
        unique: false,
        validate: {
            notEmpty: {
                msg: "Esse campo não pode está vazio.."
            },
        }
    },

    vendas: {
        type: Sequelize.STRING(150),
        allowNull: false,
        unique: false,
        validate: {
            notEmpty: {
                msg: "Esse campo não pode está vazio.."
            },
        }
    },

    dado_banc: {
        type: Sequelize.STRING(150),
        allowNull: true,
        unique: false,
        validate: {
            notEmpty: {
                msg: "Esse campo não pode está vazio.."
            },
        }
    },

    dado_pix: {
        type: Sequelize.STRING(150),
        allowNull: true,
        unique: false
    },

    site_venda: {
        type: Sequelize.STRING(150),
        allowNull: false,
        unique: false,
        validate: {
            notEmpty: {
                msg: "Esse campo não pode está vazio.."
            },
        }
    },

    siteTitle: {
        type: Sequelize.STRING(255),
        allowNull: true,
        unique: false
    },

    siteEmail: {
        type: Sequelize.STRING(255),
        allowNull: true,
        unique: false
    },

    emailModel: {
        type: Sequelize.INTEGER(2),
        allowNull: true
    },

    status: {
        type: Sequelize.STRING(150),
        allowNull: false,
        unique: false,
        validate: {
            notEmpty: {
                msg: "Esse campo não pode está vazio.."
            },
        }
    },

    perfil: {
        type: Sequelize.STRING(150),
        allowNull: false,
        unique: false,
        validate: {
            notEmpty: {
                msg: "Esse campo não pode está vazio.."
            },
        }
    },

    products: {
        type: Sequelize.STRING(150),
        allowNull: true,
        unique: false,
        validate: {
            notEmpty: {
                msg: "Esse campo não pode está vazio.."
            },
        }
    },

    precoIndividual: {
        type: Sequelize.TEXT,
        allowNull: true,
        unique: false,
    },

    precoFamiliar: {
        type: Sequelize.TEXT,
        allowNull: true,
        unique: false,
    },

    linkAndroid: {
        type: Sequelize.STRING(255),
        allowNull: true,
        unique: false
    },

    linkApple: {
        type: Sequelize.STRING(255),
        allowNull: true,
        unique: false
    },

    tokenAsaas: {
        type: Sequelize.STRING(255),
        allowNull: true,
        unique: false
    },

    subPaineis: {
        type: Sequelize.BOOLEAN(),
        allowNull: false,
        unique: false,
        /* validate: {
            notEmpty: {
                msg: "Esse campo não pode está vazio.."
            },
        } */
    },

    autoridade: {
        type: Sequelize.INTEGER,
        allowNull: false,
        unique: false
    }

});

module.exports = Franqueado;