module.exports = {
    host: "smtp.gmail.com",
    port: 465,
    auth: {
        user: 'devkledisom@gmail.com',
        pass: "ynpp dyky wvyq jhxo",//'mhhipphoaubheehg' //senha de app
    }
    /*     auth: {
            user: 'signatureprojectjp@gmail.com',
            pass: 'nxzuxoyskwbmkizv'
        } */
};

//link para gerar senha de aplicativo no gmail
//https://myaccount.google.com/apppasswords